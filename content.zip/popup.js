document.getElementById('startBtn').addEventListener('click', () => {
  const statusDiv = document.getElementById('status');
  statusDiv.textContent = 'Starting...';
  console.log('Button clicked, querying tabs...');

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    console.log('Active tab:', tabs[0]);
    if (tabs[0] && tabs[0].url.includes('school.mos.ru')) {
      console.log('Sending message to tab:', tabs[0].id);
      let responded = false;
      chrome.tabs.sendMessage(tabs[0].id, { action: 'setAbsences' }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('Runtime error:', chrome.runtime.lastError);
          statusDiv.textContent = 'Перезагрузите страницу.';
          return;
        }
        responded = true;
        console.log('Response received:', response);
        if (response && response.success) {
          statusDiv.textContent = 'Process completed!';
        } else {
          statusDiv.textContent = 'Error: ' + (response ? response.error : 'No response');
        }
      });
      // Timeout after 10 seconds
      setTimeout(() => {
        if (!responded) {
          console.log('No response within timeout');
          statusDiv.textContent = 'Warning: Timeout - no response from content script';
        }
      }, 100000);
    } else {
      statusDiv.textContent = 'Перейдите в МЭШ.';
    }
  });
});


// Listen for log messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'log') {
    const statusDiv = document.getElementById('status');
    statusDiv.textContent += '\n' + message.message;
  } else if (message.type === 'error') {
    const statusDiv = document.getElementById('status');
    statusDiv.textContent += '\nError: ' + message.message;
  } else if (message.type === 'progress') {
    const progressBar = document.getElementById('progressBar');
    progressBar.value = message.value;
    progressBar.textContent = message.value + '%';
  }
});
let STUDENTS_MARKS = [];
let LESSONS = [];
let CONTROL_FORM_ID = null;
let GROUP_ID = null;
let SUBJECT_ID = null;
let GRADE_SYSTEM_ID = null;
let COURSE_LESSON_TOPIC_ID = null;

function getLessonDateRange() {
  const useLessonDateRange = document.getElementById('useLessonDateRange');
  const lessonDateFrom = document.getElementById('lessonDateFrom');
  const lessonDateTo = document.getElementById('lessonDateTo');

  const isEnabled = Boolean(useLessonDateRange?.checked);
  const dateFrom = lessonDateFrom?.value || '';
  const dateTo = lessonDateTo?.value || '';

  return {
    useLessonDateRange: isEnabled,
    dateFrom,
    dateTo
  };
}

document.addEventListener('DOMContentLoaded', () => {
  const groupSelect = document.getElementById('groupSelect');
  const statusDiv = document.getElementById('status');
  const useLessonDateRange = document.getElementById('useLessonDateRange');
  const lessonDateFrom = document.getElementById('lessonDateFrom');
  const lessonDateTo = document.getElementById('lessonDateTo');
  const lessonDateRange = document.getElementById('lessonDateRange');

  // Устанавливаем дефолтные даты для диапазона ДЗ
  const today = new Date();
  const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
  const todayStr = today.toISOString().split('T')[0];
  const firstDayStr = firstDay.toISOString().split('T')[0];
  const hwDateFrom = document.getElementById('hwDateFrom');
  const hwDateTo = document.getElementById('hwDateTo');
  if (hwDateFrom) hwDateFrom.value = firstDayStr;
  if (hwDateTo) hwDateTo.value = todayStr;

  const updateLessonDateInputs = () => {
    const disabled = !useLessonDateRange.checked;
    lessonDateRange.style.display = disabled ? 'none' : 'flex';
    lessonDateFrom.disabled = disabled;
    lessonDateTo.disabled = disabled;
  };

  updateLessonDateInputs();
  useLessonDateRange.addEventListener('change', updateLessonDateInputs);

  statusDiv.textContent = 'Starting...';
  console.log('Button clicked, querying tabs...');

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    console.log('Active tab:', tabs[0]);
    if (tabs[0] && tabs[0].url.includes('school.mos.ru')) {
      console.log('Sending message to tab:', tabs[0].id);
      let responded = false;
      chrome.tabs.sendMessage(tabs[0].id, { action: 'getGroups' }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('Runtime error:', chrome.runtime.lastError);
          statusDiv.textContent = 'Перезагрузите страницу.';
          return;
        }
        responded = true;
        console.log('Response received:', response);
        if (response && response.success && response.groups) {
          // Populate the select element with groups
          groupSelect.innerHTML = ""; // Clear existing options
          const optionSelectSub = document.createElement('option');
          optionSelectSub.value = "";
          optionSelectSub.textContent = "Выберите группу";
          optionSelectSub.selected = true;
          groupSelect.appendChild(optionSelectSub);
          response.groups.forEach(group => {
            const option = document.createElement('option');
            option.value = group.id;
            option.textContent = `${group.class_level_id} - ${group.name}`;
            option.dataset.subjectId = group.subject_id;
            option.dataset.classLevelId = group.class_level_id;
            option.dataset.studentIds = group.student_ids.join(',');
            groupSelect.appendChild(option);
          });
          statusDiv.textContent = 'Groups loaded successfully!';
        } else {
          statusDiv.textContent = 'Error: ' + (response ? response.error : 'No response');
        }
      });
      // Timeout after 10 seconds
      setTimeout(() => {
        if (!responded) {
          console.log('No response within timeout');
          statusDiv.textContent = 'Warning: Timeout - no response from content script';
        }
      }, 10000);
    } else {
      statusDiv.textContent = 'Перейдите в МЭШ.';
    }
  });
  // Пример получения subject_id при выборе:
  document.getElementById('groupSelect').addEventListener('change', function(e) {
    const selectedOption = e.target.options[e.target.selectedIndex];
    //const subjectId = selectedOption.dataset.subjectId;
    const classLevelId = selectedOption.dataset.classLevelId;
    SUBJECT_ID = selectedOption.dataset.subjectId;
    GROUP_ID = e.target.value;
    const studentIds = selectedOption.dataset.studentIds;
    const lessonDateRange = getLessonDateRange();

    if (lessonDateRange.useLessonDateRange && (!lessonDateRange.dateFrom || !lessonDateRange.dateTo)) {
      statusDiv.textContent = 'Выберите обе даты: от и до.';
      return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    console.log('Active tab:', tabs[0]);
    if (tabs[0] && tabs[0].url.includes('school.mos.ru')) {
      console.log('Sending message to tab:', tabs[0].id);
      let responded = false;
      chrome.tabs.sendMessage(tabs[0].id, {
        action: 'setDefaultForMarks',
        group_id: GROUP_ID,
        subject_id: SUBJECT_ID,
        class_level_id: classLevelId,
        student_ids: studentIds,
        use_lesson_date_range: lessonDateRange.useLessonDateRange,
        lesson_date_from: lessonDateRange.dateFrom,
        lesson_date_to: lessonDateRange.dateTo
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('Runtime error:', chrome.runtime.lastError);
          statusDiv.textContent = 'Перезагрузите страницу.';
          
          return;
        }
        responded = true;
        console.log('Response received:', response);
        if (response && response.success && response.result) {
          //statusDiv.textContent = `Control form: ${response.result.controlFormId} \n Class level id: ${classLevelId} \n Grade system id: ${response.result.gradeSystemId} \n Course Lessont topic id: ${response.result.courseLessonTopicId} \n Average marks: ${JSON.stringify(response.result.averageMarks)} \n Lessons: ${response.result.lessonsIds.join(', ')}`;
          STUDENTS_MARKS = response.result.averageMarks;
          LESSONS = response.result.lessonsIds;
          CONTROL_FORM_ID = response.result.controlFormId;
          GRADE_SYSTEM_ID = response.result.gradeSystemId;
          COURSE_LESSON_TOPIC_ID = response.result.courseLessonTopicId;
          statusDiv.textContent = `G: ${GROUP_ID}\n`+
          `S: ${SUBJECT_ID}\n`+
          `SM: ${STUDENTS_MARKS}\n`+
          `L: ${LESSONS}\n`+
          `CF: ${CONTROL_FORM_ID}\n`+
          `GS: ${GRADE_SYSTEM_ID}\n`+
          `CLT: ${COURSE_LESSON_TOPIC_ID}`;
        } else {
          statusDiv.textContent = 'Error: ' + (response ? response.error : 'No response');
        }
      });
      // Timeout after 10 seconds
      setTimeout(() => {
        if (!responded) {
          console.log('No response within timeout');
          statusDiv.textContent = 'Warning: Timeout - no response from content script';
        }
      }, 10000);
    } else {
      statusDiv.textContent = 'Перейдите в МЭШ.';
    }
  });
  });
});
document.getElementById('setMarks').addEventListener('click', () => {
  const statusDiv = document.getElementById('status');
  statusDiv.textContent = 'Starting...';
  console.log('Button clicked, querying tabs...');

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    console.log('Active tab:', tabs[0]);
    if (tabs[0] && tabs[0].url.includes('school.mos.ru')) {
      console.log('Sending message to tab:', tabs[0].id);
      let responded = false;
      chrome.tabs.sendMessage(tabs[0].id, { action: 'setMarks', students_marks: STUDENTS_MARKS, lessons: LESSONS, control_form_id: CONTROL_FORM_ID, grade_system_id: GRADE_SYSTEM_ID, course_lesson_topic_id: COURSE_LESSON_TOPIC_ID }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('Runtime error:', chrome.runtime.lastError);
          statusDiv.textContent = 'Error: ' + chrome.runtime.lastError.message + '. Try reloading the page.';
          return;
        }
        responded = true;
        console.log('Response received:', response);
        if (response && response.success) {
          statusDiv.textContent = 'Process completed!';
        } else {
          statusDiv.textContent = 'Error: ' + (response ? response.error : 'No response');
        }
      });
      // Timeout after 10 seconds
      setTimeout(() => {
        if (!responded) {
          console.log('No response within timeout');
          statusDiv.textContent = 'Warning: Timeout - no response from content script';
        }
      }, 10000);
    } else {
      statusDiv.textContent = 'Перейдите в МЭШ.';
    }
  });
});
document.getElementById('syncKTP').addEventListener('click', () => {
  const statusDiv = document.getElementById('status');
  statusDiv.textContent = 'Starting...';
  console.log('Button clicked, querying tabs...');

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    console.log('Active tab:', tabs[0]);
    if (tabs[0] && tabs[0].url.includes('school.mos.ru')) {
      console.log('Sending message to tab:', tabs[0].id);
      let responded = false;
      chrome.tabs.sendMessage(tabs[0].id, { action: 'syncKTP' }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('Runtime error:', chrome.runtime.lastError);
          statusDiv.textContent = 'Перезагрузите страницу.';
          return;
        }
        responded = true;
        console.log('Response received:', response);
        if (response && response.success) {
          statusDiv.textContent = 'Process completed!';
        } else {
          statusDiv.textContent = 'Error: ' + (response ? response.error : 'No response');
        }
      });
      // Timeout after 10 seconds
      setTimeout(() => {
        if (!responded) {
          console.log('No response within timeout');
          statusDiv.textContent = 'Error: Timeout - no response from content script';
        }
      }, 10000);
    } else {
      statusDiv.textContent = 'Перейдите в МЭШ.';
    }
  });
});

// Кнопка добавления ДЗ на диапазон дат
document.getElementById('addHomeworkBtn').addEventListener('click', () => {
  const statusDiv = document.getElementById('status');
  const description = document.getElementById('hwDescription').value;
  const dateFrom = document.getElementById('hwDateFrom').value;
  const dateTo = document.getElementById('hwDateTo').value;

  if (!description || !dateFrom || !dateTo) {
    statusDiv.textContent = 'Заполните описание и диапазон дат.';
    return;
  }

  if (dateFrom > dateTo) {
    statusDiv.textContent = 'Дата "С" не может быть позже даты "По".';
    return;
  }

  // Форматируем даты в ДД.ММ.ГГГГ
  const formatDate = (dateStr) => {
    const [y, m, d] = dateStr.split('-');
    return `${d}.${m}.${y}`;
  };

  statusDiv.textContent = 'Массовое добавление ДЗ...';
  console.log('Sending addHomeworkForPeriod action...');

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0] && tabs[0].url.includes('school.mos.ru')) {
      let responded = false;
      chrome.tabs.sendMessage(tabs[0].id, {
        action: 'addHomeworkForPeriod',
        description: description,
        date_from: formatDate(dateFrom),
        date_to: formatDate(dateTo)
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('Runtime error:', chrome.runtime.lastError);
          statusDiv.textContent = 'Ошибка: ' + chrome.runtime.lastError.message + '. Перезагрузите страницу.';
          return;
        }
        responded = true;
        console.log('Response received:', response);
        if (response && response.success) {
          statusDiv.textContent = 'ДЗ успешно добавлено на диапазон!';
        } else {
          statusDiv.textContent = 'Ошибка: ' + (response?.error || 'Нет ответа');
        }
      });
      setTimeout(() => {
        if (!responded) {
          statusDiv.textContent = 'Таймаут - нет ответа от content script';
        }
      }, 30000);
    } else {
      statusDiv.textContent = 'Перейдите в МЭШ.';
    }
  });
});